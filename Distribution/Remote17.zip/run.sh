java -cp dist/JavaSim.jar:lib/log4j-1.2.15.jar de.tzi.Main

